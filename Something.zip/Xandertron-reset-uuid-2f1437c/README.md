# reset-uuid
A simple mindustry mod that allows you to change your uuid, works on mobile

~~Requires [UI-Lib](https://github.com/DeltaNedas/ui-lib)~~

ui-lib got blacklisted, so this plugin nolonger works
